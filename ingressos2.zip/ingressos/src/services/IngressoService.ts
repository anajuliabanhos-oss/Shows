import { IngressosRepository } from "../repositorys/IngressosRepository";
import { LogRepository } from "../repositorys/LogRepository";

export class IngressosService {
  private repo = new IngressosRepository();
  private logRepo = new LogRepository();

  async criarIngresso(
    nome: string,
    descricao: string,
    data: string,
    usuario_id: number
  ) {
    if (!nome || !descricao || !data || !usuario_id) {
      throw new Error("Dados incompletos para criar ingresso.");
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) {
      throw new Error("Data inválida. Use o formato YYYY-MM-DD.");
    }

    const ingresso = await this.repo.create({
      nome,
      descricao,
      data,
      usuario_id
    });

    await this.logRepo.registrar(usuario_id, `Criou o ingresso ${ingresso.nome}`);

    return {
      mensagem: "Ingresso criado com sucesso!",
      ingresso: {
        id: ingresso.id,
        nome: ingresso.nome,
        descricao: ingresso.descricao,
        data: ingresso.data,
      },
    };
  }

  async listarIngressos() {
    const ingressos = await this.repo.findAll();
    return ingressos;
  }

  async buscarIngressos(id: number) {
    const ingresso = await this.repo.findById(id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");
    return ingresso;
  }

  async atualizarIngressos(
    id: number,
    dados: { nome?: string; descricao?: string; data?: string }
  ) {
    const ingresso = await this.repo.findById(id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");

    const atualizado = await this.repo.update(id, dados);

    await this.logRepo.registrar(ingresso.usuario_id, `Atualizou o Ingresso ID ${id}`);

    return {
      mensagem: "Ingresso atualizado com sucesso!",
      ingresso: atualizado,
    };
  }

  async deletarIngressos(id: number, usuario_id: number) {
    const ingresso = await this.repo.findById(id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");

    await this.repo.delete(id);

    await this.logRepo.registrar(ingresso.usuario_id, `Deletou o ingresso ID ${id}`);

    return {
      mensagem: "Ingresso deletado com sucesso!"
    }
  }
}