import bcrypt from "bcryptjs";
import { LogRepository } from "../repositorys/LogRepository";
import { UsuarioRepository } from "../repositorys/UsuarioRepository";

export class UsuarioService {
    private repo = new UsuarioRepository();
    private logrepo = new LogRepository();

    async registrar( nome: string,  email: string, senha: string){

    const existente = await this.repo.findByEmail(email);
    if (existente) {
        throw new Error("Email já está em uso!")
    }

    const hast = await bcrypt.hash(senha, 10);

    const usuario = await this.repo.create({ nome, email, senha: hast});

    if (!usuario.id) {
        throw new Error("Erro ao criar usuário - ID não retornado pelo repositório!")
    }

    await this.logrepo.registrar(usuario.id!, "Criou conta");
    return {
        mensagem: "Usuário criado com sucesso!",
        usuario: {
            id: usuario.id,
            nome: usuario.nome,
            email: usuario.email
        }
    }

    }

    async login(email: string, senha: string){
    const usuario = await this.repo.findByEmail(email);
    
    if (!usuario) throw new Error ("usuario não encontrado");
    
    const match = await bcrypt.compare(senha, usuario.senha);

    if (!match) throw new Error ("Senha invalida");

    await this.logrepo.registrar(usuario.id!, "Login realizado");

    return {
        mensagem: "Login bem-sucedido!",
        usuario: {
            id: usuario.id,
            nome: usuario.nome,
            email: usuario.email
        }
    }

    }
}