import { IngressosRepository } from "../repositorys/IngressosRepository";
import { LogRepository } from "../repositorys/LogRepository";
import { ShowRepository } from "../repositorys/ShowsRepository";

export class ShowService {
  private repo = new ShowRepository();
  private ingressoRepo = new IngressosRepository();
  private logRepo = new LogRepository();

  async criarShow(
    nome: string,
    artista: string,
    horario: string,
    ingresso_id: number,
    usuario_id: number
  ) {
    if (!nome || !artista || !horario || !ingresso_id || !usuario_id) {
      throw new Error("Dados incompletos para criar show.");
    }

    if (!/^\d{2}:\d{2}$/.test(horario)) {
      throw new Error("Horário inválido. Use o formato HH:MM.");
    }

    const ingresso = await this.ingressoRepo.findById(ingresso_id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");

    const show = await this.repo.create({
      nome,
      artista,
      horario,
      ingresso_id
    });

    await this.logRepo.registrar(usuario_id, `Criou show ${nome} no ingresso ${ingresso.nome}`);

    return {
      mensagem: "Show criado com sucesso!",
      show: {
      id: show.id,
      nome: show.nome,
      artista: show.artista,
      horario: show.horario,
      ingresso_id: show.ingresso_id
    }
  }
}

  async listarShows() {
    const shows = await this.repo.findAll();
    return shows;
  }

  async buscarShow(id: number) {
    const show = await this.repo.findById(id);
    if (!show) throw new Error("Show não encontrado.");
    return show;
  }

  async atualizarShow(
    id: number,
    dados: {
      nome?: string;
      artista?: string;
      horario?: string;
      ingresso_id?: number;
      usuario_id: number;
    }
  ) {
    const showAtual = await this.repo.findById(id);
    if (!showAtual) throw new Error("Show não encontrado.");

    if (dados.ingresso_id) {
      const ingressoExiste = await this.ingressoRepo.findById(dados.ingresso_id);
      if (!ingressoExiste) {
        throw new Error("Ingresso informado não existe.");
      }
    }

    const atualizado = await this.repo.update(id, dados);

    await this.logRepo.registrar(
      dados.usuario_id,
      `Atualizou show ID ${id}`
    );

    return {
      mensagem: "Show atualizado com sucesso!",
      show: atualizado
    }
  }

  async deletarShow(id: number, usuario_id: number) {
    const show = await this.repo.findById(id);
    if (!show) throw new Error("Show não encontrado.");

    await this.repo.delete(id);

    await this.logRepo.registrar(usuario_id, `Deletou show ID ${id}`);

    return {
      mensagem: "Show deletado com sucesso!"
    };
  }
}