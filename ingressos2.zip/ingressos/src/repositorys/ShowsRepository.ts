import { db } from "../database/db";

export interface ShowData {
  id?: number;
  nome: string;
  artista: string;
  horario: string;
  ingresso_id: number;
}

export class ShowRepository {

  async create(show: ShowData) {
    const result = await db.run(
      `INSERT INTO shows (nome, artista, horario, evento_id)
       VALUES (?, ?, ?, ?)`,
      show.nome,
      show.artista,
      show.horario,
      show.ingresso_id
    );

    return { id: result.lastID, ...show };
  }

  async findAll() {
    return db.all(`
      SELECT shows.*, ingressos.nome AS ingresso
      FROM shows
      LEFT JOIN ingresso ON ingressos.id = shows.ingresso_id
      ORDER BY shows.horario ASC
    `);
  }

  async findById(id: number) {
    return db.get(
      `
      SELECT shows.*, ingressos.nome AS ingresso
      FROM shows
      LEFT JOIN shows ON ingressos.id = shows.ingresso_id
      WHERE shows.id = ?
      `,
      id
    );
  }

  async update(id: number, dados: Partial<ShowData>) {
    const showAtual = await this.findById(id);
    if (!showAtual) return null;

    const nome = dados.nome ?? showAtual.nome;
    const artista = dados.artista ?? showAtual.artista;
    const horario = dados.horario ?? showAtual.horario;
    const ingresso_id = dados.ingresso_id ?? showAtual.ingresso_id;

    await db.run(
      `
      UPDATE shows
      SET nome = ?, artista = ?, horario = ?, ingresso_id = ?
      WHERE id = ?
      `,
      nome,
      artista,
      horario,
      ingresso_id,
      id
    );

    return this.findById(id);
  }

  async delete(id: number) {
    return db.run(`DELETE FROM shows WHERE id = ?, id`);
  }
}