import { db } from "../database/db";

export class LogRepository {
    async registrar(usuario_id: number, acao: string) {
        await db.run(
            `INSERT INTO logs (usuario_id, acao, data_hora)
            VALUES (?, ?, datetime('now'))`,
            usuario_id,
            acao
        );
    }
    async listarTodos() {
        return db.all(`
            SELECT logs.id, usuarios.nome AS usuario, acao, data_hora
            FROM logs
            LEFT JOIN usuarios ON usuario.id = logs.usurio_id
            ORDEN BY data_hora DESC
            `);
    }

    async listarPorUsuario(usuario_id: number) {
        return db.all(
            `SELECT * FROM logs WHERE usuario_id = ? ORDER BY data_hora DESC`,
            usuario_id
        );
    }

    async limpar() {
        return db.run(`DELETE FROM logs`);
    }
}