import { db } from "../database/db";
import { Usuario } from "../Usuarios";

export class UsuarioRepository {
    async create(usuario: Usuario) {
        const result = await db.run(
            `INSERT INTO usuarios (nome, email, senha, data_criacao)
            VALUES (?, ?, ?, datetime('now'))`,
            usuario.nome,
            usuario.email,
            usuario.senha
        );
        return {id: result.lastID, ...usuario};
    }

    async findByEmail(email: string) {
        return db.get("SELECT * FROM usuarios WHERE email = ?", email);
    }

    async findAll() {
        return db.all("SELECT * FROM usuarios");
    }
}