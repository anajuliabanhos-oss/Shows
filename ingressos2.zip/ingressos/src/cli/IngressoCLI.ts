import inquirer from "inquirer";
import { IngressoController } from "../controllers/IngressoController";

export async function ingressosMenu() {
    while (true) {
    const { op } = await inquirer.prompt({
        type: "list",
        name: "op",
        message: "Ingressos - Escolha uma opção:",
        choices: [ "Criar Ingresso", "Listar Ingressos", "Deletar Ingresso", "Voltar" ]
    });

    if (op === "Voltar") break;

    if (op === "Criar Ingresso") {
        const dados = await inquirer.prompt([
            { type: "input", name: "nome", message: "Nome do Ingresso:" },
            { type: "input", name: "descricao", message: "Descrição:" },
            { type: "input", name: "data", message: "YYYY-MM-DD:" },
            { type: "number", name: "usuario_id", message: "ID do Criador:"}
        ]);

         try {
        const resultado = await IngressoController.criar(
          dados.nome,
          dados.descricao,
          dados.data,
          dados.usuario_id
        );
        console.log(resultado.mensagem);
        console.table(resultado.ingresso);
      } catch (error: any) {
        console.error("Erro:", error.message);
      }
    }

    if (op === "Listar Ingressos") {
        try {
            const ingressos = await IngressoController.listar();
            console.table(ingressos);
        } catch (error: any) {
            console.error("Erro:", error.message);
        }
    }

if (op === "Deletar Ingresso") {
      const dados = await inquirer.prompt([
        { type: "number", name: "id", message: "ID do ingresso:" },
        { type: "number", name: "usuario_id", message: "ID do usuário que deleta:" }
      ]);

      try {
        const resultado = await IngressoController.deletar(
          dados.id,
          dados.usuario_id
        );
        console.log(resultado.mensagem);
      } catch (error: any) {
        console.error("Erro:", error.message);
      }
    }
  }
}