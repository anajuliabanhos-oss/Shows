import inquirer from "inquirer";
import { ShowController } from "../controllers/ShowController";

export async function showMenu() {
  while (true) {
  const { op } = await inquirer.prompt({
    type: "list",
    name: "op",
    message: "Menu de Shows",
    choices: [ "Criar Show", "Listar Shows", "Buscar Show por ID", "Atualizar Show", "Deletar Show", "Voltar" ]
  });

  if (op === "Voltar") break;

  if (op === "Criar Show") {
    const dados = await inquirer.prompt([
      { type: "input", name: "nome", message: "Nome do show:" },
      { type: "input", name: "artista", message: "Artista:" },
      { type: "input", name: "horario", message: "Horário (HH:MM):" },
      { type: "number", name: "ingresso_id", message: "ID do ingresso:" },
      { type: "number", name: "usuario_id", message: "ID do usuário criador:" }
    ]);

    try {
      const show = await ShowController.criar;
      console.log(show);
    } catch (error: any) {
      console.log("Erro:", error.message);
    }
  }

  if (op === "Listar Shows") {
    const shows = await ShowController.listar();
    console.table(shows);
  }

  if (op === "Buscar Show por ID") {
    const { id } = await inquirer.prompt({
      type: "number",
      name: "id",
      message: "ID do show:"
    });

    try {
      const show = await ShowController.buscarPorId(id);
      console.log(show);
    } catch (error: any) {
      console.log("Show não encontrado.");
    }
  }

  if (op === "Atualizar Show") {
    const base = await inquirer.prompt([
      { type: "number", name: "id", message: "ID do show:" },
      { type: "number", name: "usuario_id", message: "ID do usuário:" }
    ]);

    const updates = await inquirer.prompt([
      { type: "input", name: "nome", message: "Novo nome (ou Enter):" },
      { type: "input", name: "artista", message: "Novo artista (ou Enter):" },
      { type: "input", name: "horario", message: "Novo horário (ou Enter):" },
      { type: "input", name: "ingresso_id", message: "Novo ingresso_id (ou Enter):" }
    ]);

    const dadosAtualizados = {
      ...updates,
      ingresso_id: updates.ingresso_id ? Number(updates.ingresso_id) : undefined,
      usuario_id: base.usuario_id
    };

    try {
      const result = await ShowController.atualizar(base.id, dadosAtualizados);
      console.log(result);
    } catch (error: any) {
      console.log("Erro:", error.message);
    }
  }

  if (op === "Deletar Show") {
    const dados = await inquirer.prompt([
      { type: "number", name: "id", message: "ID do show:" },
      { type: "number", name: "usuario_id", message: "ID do usuário:" }
    ]);

    try {
      await ShowController.deletar(dados.id, dados.usuario_id);
      console.log("Show deletado.");
    } catch (error: any) {
      console.log("Erro:", error.message);
    }
  }
}
}