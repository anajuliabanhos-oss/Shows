import inquirer from "inquirer";
import { UsuarioController } from "../controllers/UsuarioController";

export async function usuarioMenu() {
    while (true) {
    const { op } = await inquirer.prompt({
        type: "list",
        name: "op",
        message: "Usuários - Escolha uma opção:",
        choices: [ "Registrar", "Login", "Voltar" ]
    });

    if (op === "Voltar") break;

    if (op === "Registrar") {
        const dados = await inquirer.prompt([
            { type: "input", name: "nome", message: "Nome:" },
            { type: "input", name: "email", message: "Email:" },
            { type: "password", name: "senha", message: "Senha:" }
        ]);

        const usuario = await UsuarioController.registrar(
            dados.nome,
            dados.email,
            dados.senha
        );

        console.log("Usuário Criado:", usuario)
    }

    if (op === "Login") {
        const dados = await inquirer.prompt([
            { type: "input", name: "email", message: "Email:" },
            { type: "password", name: "senha", message: "Senha:" }
        ]);

    try {const usuario = await UsuarioController.login(
            dados.email,
            dados.senha
        );

        console.log("Login bem-sucedido:", usuario);
        } catch (error: any) {
        console.error("Erro:", error.message);
        }
    }
}
}