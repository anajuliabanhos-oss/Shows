import { ShowService } from "../services/ShowService";

const service = new ShowService();

export const ShowController = {
  async criar(
    nome: string,
    artista: string,
    horario: string,
    ingresso_id: number,
    usuario_id: number
  ) {
    return await service.criarShow(
      nome,
      artista,
      horario,
      ingresso_id,
      usuario_id
    );
  },

  async listar() {
    return service.listarShows();
  },

  async buscarPorId(id: number) {
    return service.buscarShow(id);
  },

  async atualizar(
    id: number,
    dados: {
      nome?: string;
      artista?: string;
      horario?: string;
      ingresso_id?: number;
      usuario_id: number;
    }
  ) {
    return await service.atualizarShow(id, dados);
  },

  async deletar(id: number, usuario_id: number) {
    return await service.deletarShow(id, usuario_id);
  }
};