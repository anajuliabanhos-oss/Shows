import { UsuarioService } from "../services/UsuarioService";

const service = new UsuarioService();

export const UsuarioController = {
  async registrar(nome: string, email: string, senha: string) {
    return await service.registrar(nome, email, senha);
  },

  async login(email: string, senha: string) {
    return await service.login(email, senha);
  }
};