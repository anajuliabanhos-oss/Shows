import { IngressosService } from "../services/IngressoService";

const service = new IngressosService();

export const IngressoController = {
  async criar( 
    nome: string,
    descricao: string,
    data: string,
    usuario_id: number
  ) {
    return await service.criarIngresso(
      nome,
      descricao,
      data,
      usuario_id
    );
  },

  async listar() {
    return await service.listarIngressos();
  },

  async buscarPorId(id: number) {
    return await service.buscarIngressos(id);
  },

  async atualizar(
    id: number,
    dados: { nome?: string; descricao?: string; data?: string; usuario_id: number }
  ) {
    return await service.atualizarIngressos(id, dados);
  },

  async deletar(id: number, usuario_id: number) {
    return await service.deletarIngressos(id, usuario_id);
  },
};