import inquirer from "inquirer";
import { usuarioMenu } from "./cli/UsuariosCLI";
import { ingressosMenu } from "./cli/IngressoCLI";
import { showMenu } from "./cli/ShowCLI";

export async function menu() {
    while (true) {
        console.clear();
        console.log("Sistema de Gestão de Shows")

        const { op } = await inquirer.prompt({
        type: "list",
        name: "op",
        message: "Menu Principal",
        choices: [
            "Usuários",
            "Ingressos",
            "Shows",
            "Sair"
        ]
        });

        switch (op) {
      case "Usuários":
        await usuarioMenu();
        break;

      case "Ingressos":
        await ingressosMenu();
        break;

      case "Shows":
        await showMenu();
        break;

      case "Sair":
        console.log("Encerrando o sistema!");
        return;
    }
  }
}