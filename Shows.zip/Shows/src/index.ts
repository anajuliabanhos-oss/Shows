import { initDB } from "./database/db";
import { menu } from "./Menu";

(async () => {
  try {
    await initDB();
    console.log("Banco de dados carregado!");
    
    await menu();
    
  } catch (err) {
    console.error("Erro na aplicação:", err);
  }
})();