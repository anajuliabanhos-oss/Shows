import { Ingressos } from "../models/Ingressos";
import { createIngressosService } from "../services/IngressoService";

const service = createIngressosService();

export const IngressoController = {
  async criar(ingresso: Ingressos) {
    return await service.criarIngresso(ingresso);
  },

  async listar() {
    return await service.listarIngressos();
  },

  async buscarPorId(id: number) {
    return await service.buscarIngressos(id);
  },

  async atualizar(
    id: number,
    dados: { nome?: string; descricao?: string; data?: string; usuario_id: number }
  ) {
    return await service.atualizarIngressos(id, dados);
  },

  async deletar(id: number, usuario_id: number) {
    return await service.deletarIngressos(id, usuario_id);
  },
};