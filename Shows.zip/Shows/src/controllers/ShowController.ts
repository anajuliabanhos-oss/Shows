import { Shows } from "../models/Shows";
import { createShowService } from "../services/ShowService";

const service = createShowService();

export const ShowController = {
  async criar(show: Shows) {
    return service.criarShow(show);
  },

  async listar() {
    return service.listarShows();
  },

  async buscarPorId(id: number) {
    return service.buscarShow(id);
  },

  async atualizar(id: number, dados: Partial<Shows> & { usuario_id: number }) {
    return service.atualizarShow(id, dados);
  },

  async deletar(id: number, usuario_id: number) {
    return service.deletarShow(id, usuario_id);
  },
};