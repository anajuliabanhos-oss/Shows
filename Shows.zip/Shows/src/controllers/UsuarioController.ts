import { createUsuarioService } from "../services/UsuarioService";

const service = createUsuarioService();

export const UsuarioController = {
  async registrar(dados: { nome: string; email: string; senha: string }) {
    return await service.registrar(dados);
  },
  async login(dados: { email: string; senha: string }) {
    return await service.login(dados);
  },
};