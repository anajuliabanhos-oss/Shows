import promptSync from "prompt-sync";
import { usuarioMenu } from "./cli/UsuariosCLI";
import { ingressosMenu } from "./cli/IngressoCLI";
import { showMenu } from "./cli/ShowCLI";

const prompt = promptSync({ sigint: true });

export function menu() {
  while (true) {
    console.clear();
    console.log("=== Sistema de Gestão de Shows ===\n");
    console.log("1 - Usuários");
    console.log("2 - Ingressos");
    console.log("3 - Shows");
    console.log("0 - Sair");

    const op = prompt("Escolha uma opção: ").trim();

    switch (op) {
      case "1":
        usuarioMenu();
        break;

      case "2":
        ingressosMenu();
        break;

      case "3":
        showMenu();
        break;

      case "0":
        console.log("Encerrando o sistema!");
        return;

      default:
        console.log("Opção inválida! Tente novamente.");
        break;
    }
  }
}