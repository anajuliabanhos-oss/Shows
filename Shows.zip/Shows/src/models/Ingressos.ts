export interface Ingressos {
    id?: number,
    nome: string,
    descricao?: string,
    data: string,
    usuario_id?: number
}