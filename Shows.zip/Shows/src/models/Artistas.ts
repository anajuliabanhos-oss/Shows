export interface Artistas {
    id?: number,
    nome: string,
    genero: string,
    biografia?: string
}