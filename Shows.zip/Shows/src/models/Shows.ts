export interface Shows {
  id?: number;
  nome: string;
  artista: string;
  horario: string;
  ingresso_id: number;
  usuario_id: number;
}