import bcrypt from "bcryptjs";
import { createLogRepository } from "../repositorys/LogRepository";
import { createUsuarioRepository } from "../repositorys/UsuarioRepository";

export function createUsuarioService() {
  const repo = createUsuarioRepository();
  const logrepo = createLogRepository();

  async function registrar(dados: { nome: string; email: string; senha: string }) {
    const existente = await repo.findByEmail(dados.email);
    if (existente) throw new Error("Email já está em uso!");

    const hash = await bcrypt.hash(dados.senha, 10);

    const usuario = await repo.create({ nome: dados.nome, email: dados.email, senha: hash });

    await logrepo.registrar(usuario.id!, "Criou conta");

    return {
      mensagem: "Usuário criado com sucesso!",
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email
      }
    };
  }

  async function login(dados: { email: string; senha: string }) {
    const usuario = await repo.findByEmail(dados.email);
    if (!usuario) throw new Error("Usuário não encontrado");

    const match = await bcrypt.compare(dados.senha, usuario.senha);
    if (!match) throw new Error("Senha inválida");

    await logrepo.registrar(usuario.id!, "Login realizado");

    return {
      mensagem: "Login bem-sucedido!",
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email
      }
    };
  }

  return { registrar, login };
}