import { Shows } from "../models/Shows";
import { createShowRepository } from "../repositorys/ShowsRepository";
import { createIngressosRepository } from "../repositorys/IngressosRepository";
import { createLogRepository } from "../repositorys/LogRepository";

export function createShowService() {
  const repo = createShowRepository();
  const ingressoRepo = createIngressosRepository();
  const logRepo = createLogRepository();

  async function criarShow(show: Shows) {
    if (!show.nome || !show.artista || !show.horario || !show.ingresso_id || !show.usuario_id) {
      throw new Error("Dados incompletos para criar show.");
    }

    if (!/^\d{2}:\d{2}$/.test(show.horario)) {
      throw new Error("Horário inválido. Use o formato HH:MM.");
    }

    const ingresso = await ingressoRepo.findById(show.ingresso_id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");

    const novoShow = await repo.create(show);

    await logRepo.registrar(
      show.usuario_id,
      `Criou show ${show.nome} no ingresso ${ingresso.nome}`
    );

    return { mensagem: "Show criado com sucesso!", show: novoShow };
  }

  async function listarShows() {
    return repo.findAll();
  }

  async function buscarShow(id: number) {
    const show = await repo.findById(id);
    if (!show) throw new Error("Show não encontrado.");
    return show;
  }

  async function atualizarShow(id: number, dados: Partial<Shows> & { usuario_id: number }) {
    const showAtual = await repo.findById(id);
    if (!showAtual) throw new Error("Show não encontrado.");

    if (dados.ingresso_id) {
      const ingressoExiste = await ingressoRepo.findById(dados.ingresso_id);
      if (!ingressoExiste) throw new Error("Ingresso informado não existe.");
    }

    const atualizado = await repo.update(id, dados);

    await logRepo.registrar(dados.usuario_id, `Atualizou show ID ${id}`);

    return { mensagem: "Show atualizado com sucesso!", show: atualizado };
  }

  async function deletarShow(id: number, usuario_id: number) {
    const show = await repo.findById(id);
    if (!show) throw new Error("Show não encontrado.");

    await repo.delete(id);

    await logRepo.registrar(usuario_id, `Deletou show ID ${id}`);

    return { mensagem: "Show deletado com sucesso!" };
  }

  return { criarShow, listarShows, buscarShow, atualizarShow, deletarShow };
}