import { Ingressos } from "../models/Ingressos";
import { createIngressosRepository } from "../repositorys/IngressosRepository";
import { createLogRepository } from "../repositorys/LogRepository";

export function createIngressosService() {
  const repo = createIngressosRepository();
  const logRepo = createLogRepository();

  async function criarIngresso(ingresso: Ingressos) {
    if (!ingresso.nome || !ingresso.descricao || !ingresso.data || !ingresso.usuario_id) {
      throw new Error("Dados incompletos para criar ingresso.");
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(ingresso.data)) {
      throw new Error("Data inválida. Use o formato YYYY-MM-DD.");
    }

    const novoIngresso = await repo.create({
      nome: ingresso.nome,
      descricao: ingresso.descricao,
      data: ingresso.data,
      usuario_id: ingresso.usuario_id,
    });

    await logRepo.registrar(
      ingresso.usuario_id,
      `Criou o ingresso ${ingresso.nome}`
    );

    return {
      mensagem: "Ingresso criado com sucesso!",
      ingresso: {
        id: novoIngresso.id,
        nome: novoIngresso.nome,
        descricao: novoIngresso.descricao,
        data: novoIngresso.data,
      },
    };
  }

  async function listarIngressos() {
    return await repo.findAll();
  }

  async function buscarIngressos(id: number) {
    const ingresso = await repo.findById(id);

    if (!ingresso) throw new Error("Ingresso não encontrado.");

    return ingresso;
  }

  async function atualizarIngressos(
    id: number,
    dados: { nome?: string; descricao?: string; data?: string }
  ) {
    const ingresso = await repo.findById(id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");

    const atualizado = await repo.update(id, dados);

    await logRepo.registrar(
      ingresso.usuario_id,
      `Atualizou o ingresso ID ${id}`
    );

    return {
      mensagem: "Ingresso atualizado com sucesso!",
      ingresso: atualizado,
    };
  }

  async function deletarIngressos(id: number, usuario_id: number) {
    const ingresso = await repo.findById(id);
    if (!ingresso) throw new Error("Ingresso não encontrado.");

    await repo.delete(id);

    await logRepo.registrar(
      usuario_id,
      `Deletou o ingresso ID ${id}`
    );

    return {
      mensagem: "Ingresso deletado com sucesso!",
    };
  }

  return {
    criarIngresso,
    listarIngressos,
    buscarIngressos,
    atualizarIngressos,
    deletarIngressos,
  };
}