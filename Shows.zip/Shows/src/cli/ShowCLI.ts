import promptSync from "prompt-sync";
import { ShowController } from "../controllers/ShowController";
import { Shows } from "../models/Shows";

const prompt = promptSync({ sigint: true });

export function showMenu() {
  while (true) {
    console.log("\n=== Menu de Shows ===");
    console.log("1 - Criar Show");
    console.log("2 - Listar Shows");
    console.log("3 - Buscar Show por ID");
    console.log("4 - Atualizar Show");
    console.log("5 - Deletar Show");
    console.log("0 - Voltar");

    const op = prompt("Escolha uma opção: ").trim();

    if (op === "0") break;

    if (op === "1") {
      const nome = prompt("Nome do show: ");
      const artista = prompt("Artista: ");
      const horario = prompt("Horário (HH:MM): ");
      const ingresso_id = Number(prompt("ID do ingresso: "));
      const usuario_id = Number(prompt("ID do usuário criador: "));

      const dados: Shows = { nome, artista, horario, ingresso_id, usuario_id };

      ShowController.criar(dados)
        .then(res => {
          console.log(res.mensagem);
          console.table(res.show);
        })
        .catch(err => console.error("Erro:", err.message));
    }

    if (op === "2") {
      ShowController.listar()
        .then(shows => console.table(shows))
        .catch(err => console.error("Erro ao listar shows:", err.message));
    }

    if (op === "3") {
      const id = Number(prompt("ID do show: "));

      ShowController.buscarPorId(id)
        .then(show => console.log(show))
        .catch(() => console.log("Show não encontrado."));
    }

    if (op === "4") {
      const id = Number(prompt("ID do show: "));
      const usuario_id = Number(prompt("ID do usuário: "));

      const nome = prompt("Novo nome (ou Enter para manter): ");
      const artista = prompt("Novo artista (ou Enter para manter): ");
      const horario = prompt("Novo horário (ou Enter para manter): ");
      const ingresso_id_str = prompt("Novo ingresso_id (ou Enter para manter): ");

      const dadosAtualizados: Partial<Shows> & { usuario_id: number } = { usuario_id };

      if (nome.trim() !== "") dadosAtualizados.nome = nome;
      if (artista.trim() !== "") dadosAtualizados.artista = artista;
      if (horario.trim() !== "") dadosAtualizados.horario = horario;
      if (ingresso_id_str.trim() !== "") dadosAtualizados.ingresso_id = Number(ingresso_id_str);

      ShowController.atualizar(id, dadosAtualizados)
        .then(res => {
          console.log(res.mensagem);
          console.table(res.show);
        })
        .catch(err => console.error("Erro:", err.message));
    }

    if (op === "5") {
      const id = Number(prompt("ID do show: "));
      const usuario_id = Number(prompt("ID do usuário: "));

      ShowController.deletar(id, usuario_id)
        .then(res => console.log(res.mensagem))
        .catch(err => console.error("Erro:", err.message));
    }
  }
}