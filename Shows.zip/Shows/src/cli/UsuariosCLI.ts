import promptSync from "prompt-sync";
import { UsuarioController } from "../controllers/UsuarioController";

const prompt = promptSync();

export function usuarioMenu() {
  while (true) {
    console.log("\n=== Menu de Usuários ===");
    console.log("1 - Registrar");
    console.log("2 - Login");
    console.log("0 - Voltar");

    const op = prompt("Escolha uma opção: ");

    if (op === "0") break;

    if (op === "1") {
      const nome = prompt("Nome: ");
      const email = prompt("Email: ");
      const senha = prompt("Senha: ", { echo: "*" });

      UsuarioController.registrar({ nome, email, senha })
        .then(res => {
          console.log(res.mensagem);
          console.log(res.usuario);
        })
        .catch(err => console.error("Erro ao registrar usuário:", err.message));
    }

    if (op === "2") {
      const email = prompt("Email: ");
      const senha = prompt("Senha: ", { echo: "*" });

      UsuarioController.login({ email, senha })
        .then(res => {
          console.log(res.mensagem);
          console.log(res.usuario);
        })
        .catch(err => console.error("Erro ao fazer login:", err.message));
    }
  }
}