import promptSync from "prompt-sync";
import { IngressoController } from "../controllers/IngressoController";

const prompt = promptSync({ sigint: true });

export function ingressosMenu() {
  while (true) {
    console.log("\n=== Menu de Ingressos ===");
    console.log("1 - Criar Ingresso");
    console.log("2 - Listar Ingressos");
    console.log("3 - Deletar Ingresso");
    console.log("0 - Voltar");

    const op = prompt("Escolha uma opção: ").trim();

    if (op === "0") break;

    if (op === "1") {
      const nome = prompt("Nome do ingresso: ");
      const descricao = prompt("Descrição: ");
      const data = prompt("Data (YYYY-MM-DD): ");
      const usuario_id = Number(prompt("ID do usuário criador: "));

      IngressoController.criar({ nome, descricao, data, usuario_id })
        .then(res => {
          console.log("Ingresso criado com sucesso!");
          console.table(res.ingresso);
        })
        .catch(err => console.error("Erro ao criar ingresso:", err.message));
    }

    if (op === "2") {
      IngressoController.listar()
        .then(ingressos => {
          if (!ingressos || ingressos.length === 0) {
            console.log("Nenhum ingresso encontrado.");
          } else {
            console.table(ingressos);
          }
        })
        .catch(err => console.error("Erro ao listar ingressos:", err.message));
    }

    if (op === "3") {
      const id = Number(prompt("ID do ingresso: "));
      const usuario_id = Number(prompt("ID do usuário que deleta: "));

      IngressoController.deletar(id, usuario_id)
        .then(res => console.log(res.mensagem))
        .catch(err => console.error("Erro ao deletar ingresso:", err.message));
    }
  }
}