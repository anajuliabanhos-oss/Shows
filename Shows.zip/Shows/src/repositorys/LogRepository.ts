import { db } from "../database/db";

export function createLogRepository() {
  async function registrar(usuario_id: number, acao: string) {
    await db.run(
      `INSERT INTO logs (usuario_id, acao, data_hora)
       VALUES (?, ?, datetime('now'))`,
      usuario_id,
      acao
    );
  }

  async function listarTodos() {
    return db.all(`
      SELECT logs.id, usuarios.nome AS usuario, logs.acao, logs.data_hora
      FROM logs
      LEFT JOIN usuarios ON usuarios.id = logs.usuario_id
      ORDER BY logs.data_hora DESC
    `);
  }

  async function listarPorUsuario(usuario_id: number) {
    return db.all(
      `SELECT *
       FROM logs
       WHERE usuario_id = ?
       ORDER BY data_hora DESC`,
      usuario_id
    );
  }

  async function limpar() {
    return db.run(`DELETE FROM logs`);
  }

  return {
    registrar,
    listarTodos,
    listarPorUsuario,
    limpar,
  };
}