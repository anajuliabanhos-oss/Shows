import { db } from "../database/db";
import { Shows } from "../models/Shows";

export function createShowRepository() {
  async function create(show: Shows) {
    const result = await db.run(
      `INSERT INTO shows (nome, artista, horario, ingresso_id)
       VALUES (?, ?, ?, ?)`,
      show.nome,
      show.artista,
      show.horario,
      show.ingresso_id
    );
    return { id: result.lastID, ...show };
  }

  async function findAll() {
    return db.all(`
      SELECT shows.*, ingressos.nome AS ingresso
      FROM shows
      LEFT JOIN ingressos ON ingressos.id = shows.ingresso_id
      ORDER BY shows.horario ASC
    `);
  }

  async function findById(id: number) {
    return db.get(
      `
      SELECT shows.*, ingressos.nome AS ingresso
      FROM shows
      LEFT JOIN ingressos ON ingressos.id = shows.ingresso_id
      WHERE shows.id = ?
      `,
      id
    );
  }

  async function update(id: number, dados: Partial<Shows>) {
    const showAtual = await findById(id);
    if (!showAtual) return null;

    const nome = dados.nome ?? showAtual.nome;
    const artista = dados.artista ?? showAtual.artista;
    const horario = dados.horario ?? showAtual.horario;
    const ingresso_id = dados.ingresso_id ?? showAtual.ingresso_id;

    await db.run(
      `UPDATE shows SET nome = ?, artista = ?, horario = ?, ingresso_id = ? WHERE id = ?`,
      nome,
      artista,
      horario,
      ingresso_id,
      id
    );

    return findById(id);
  }

  async function remove(id: number) {
    return db.run(`DELETE FROM shows WHERE id = ?`, id);
  }

  return { create, findAll, findById, update, delete: remove };
}