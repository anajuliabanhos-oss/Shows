import { db } from "../database/db";
import { Ingressos } from "../models/Ingressos";

export function createIngressosRepository() {

  async function create(ingresso: Ingressos) {
    const result = await db.run(
      `INSERT INTO ingressos (nome, descricao, data, usuario_id)
       VALUES (?, ?, ?, ?)`,
      ingresso.nome,
      ingresso.descricao,
      ingresso.data,
      ingresso.usuario_id
    );

    return { id: result.lastID, ...ingresso };
  }

  async function findAll() {
    return db.all(`
      SELECT ingressos.*, usuarios.nome AS criador
      FROM ingressos
      LEFT JOIN usuarios ON usuarios.id = ingressos.usuario_id
      ORDER BY ingressos.data ASC
    `);
  }

  async function findById(id: number) {
    return db.get(
      `
      SELECT ingressos.*, usuarios.nome AS criador
      FROM ingressos
      LEFT JOIN usuarios ON usuarios.id = ingressos.usuario_id
      WHERE ingressos.id = ?
      `,
      id
    );
  }

  async function update(id: number, dados: Partial<Ingressos>) {
    const ingressoAtual = await findById(id);
    if (!ingressoAtual) return null;

    const nome = dados.nome ?? ingressoAtual.nome;
    const descricao = dados.descricao ?? ingressoAtual.descricao;
    const data = dados.data ?? ingressoAtual.data;

    await db.run(
      `
      UPDATE ingressos
      SET nome = ?, descricao = ?, data = ?
      WHERE id = ?
      `,
      nome,
      descricao,
      data,
      id
    );

    return findById(id);
  }

  async function remove(id: number) {
    return db.run(`DELETE FROM ingressos WHERE id = ?`, id);
  }

  return {
    create,
    findAll,
    findById,
    update,
    delete: remove,
  };
}
